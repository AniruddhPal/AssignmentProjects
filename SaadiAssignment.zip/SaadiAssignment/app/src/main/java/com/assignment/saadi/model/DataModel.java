package com.assignment.saadi.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class DataModel implements Serializable {
    @SerializedName("results")
    ArrayList<RowDataItem> results;

    public ArrayList<RowDataItem> getResults() {
        return results;
    }

    public void setResults(ArrayList<RowDataItem> results) {
        this.results = results;
    }
}
