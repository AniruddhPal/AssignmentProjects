package com.assignment.saadi.view;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.assignment.saadi.R;
import com.assignment.saadi.adapter.ApiCallAdapter;
import com.assignment.saadi.db.ProfileDatabase;
import com.assignment.saadi.interfaces.ApiCallContract;
import com.assignment.saadi.model.DataModel;
import com.assignment.saadi.model.ProfilePicture;
import com.assignment.saadi.model.RowDataItem;
import com.assignment.saadi.presenter.ApiCallPresenter;
import com.assignment.saadi.utils.Helper;
import com.google.gson.Gson;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements ApiCallContract.ApiCallView {

    @BindView(R.id.header_name)
    TextView headerName;
    @BindView(R.id.recycleView)
    RecyclerView recycleView;
    @BindView(R.id.progressbar)
    ProgressBar progressbar;
    @BindView(R.id.pullToRefresh)
    SwipeRefreshLayout pullToRefresh;
    private String TAG = "Saadi";
    ApiCallContract.ApiCallPresenter apiCallPresenter;
    private Gson gson = new Gson();
    ProfileDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        apiCallPresenter = new ApiCallPresenter(this);
        headerName.setText("Members interested in you");
        db = new ProfileDatabase(MainActivity.this);
        callApi();
//        pullToRefreshData();
    }

    private void pullToRefreshData() {
        pullToRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                callApi();
                pullToRefresh.setRefreshing(false);
            }
        });
    }


    private void callApi() {
        if (Helper.isConnected(this)) {
            progressbar.setVisibility(View.VISIBLE);
            apiCallPresenter.hitApiCall();
        } else {
            progressbar.setVisibility(View.GONE);
            Helper.makeText(this, getString(R.string.str_no_internet), 1);
        }
    }

    @Override
    public void successResponse(DataModel response) {
        progressbar.setVisibility(View.GONE);
        Helper.v(TAG, "Success  response size :::: " + response.getResults().size());
        Helper.v(TAG, "Success  response json :::: " + gson.toJson(response.getResults()));
        if (response != null) {
            ArrayList<RowDataItem> itemList = new ArrayList<>();
            Helper.v(TAG, "Success From DB:::: " + db.getdatafromDB().size());

            if (db.getdatafromDB().size() > 0) {
                itemList.addAll(db.getdatafromDB());
            } else {
                itemList = response.getResults();
            }


            if (itemList != null) {
                if (itemList.size() > 0) {
                    ApiCallAdapter adapter = new ApiCallAdapter(MainActivity.this, itemList);
                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(MainActivity.this);
                    recycleView.setLayoutManager(linearLayoutManager);
                    recycleView.setAdapter(adapter);
                }
            }
        }
    }


    @Override
    public void failResponse(String failMessage) {
        progressbar.setVisibility(View.GONE);
        Helper.v(TAG, "Error response :::: " + failMessage);
    }
}
