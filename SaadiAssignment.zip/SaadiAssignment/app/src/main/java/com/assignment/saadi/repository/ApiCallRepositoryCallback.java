package com.assignment.saadi.repository;

import com.assignment.saadi.model.DataModel;

import org.json.JSONObject;

public interface ApiCallRepositoryCallback {
    public void onResponseSuccess(DataModel response);
    public void onError(String msg);
}
