package com.assignment.saadi.apis;

public class WebApisConstants {
    public static final String WEB_SERVICE_API =  "https://randomuser.me/api/?results=10";
}
