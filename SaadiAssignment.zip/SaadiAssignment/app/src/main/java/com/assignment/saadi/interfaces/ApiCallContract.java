package com.assignment.saadi.interfaces;

import com.assignment.saadi.model.DataModel;

import org.json.JSONObject;

public interface ApiCallContract {
    interface ApiCallPresenter{
         void hitApiCall();
    }

    interface ApiCallView{
        void successResponse(DataModel response);
        void failResponse(String failMessage);
    }
}
