package com.assignment.saadi.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class ProfilePicture implements Serializable {

    @SerializedName("large")
    private String largeImage;
    @SerializedName("medium")
    private String mediumImage;
    @SerializedName("thumbnail")
    private String thumbnailImage;

    public String getLargeImage() {
        return largeImage;
    }

    public void setLargeImage(String largeImage) {
        this.largeImage = largeImage;
    }

    public String getMediumImage() {
        return mediumImage;
    }

    public void setMediumImage(String mediumImage) {
        this.mediumImage = mediumImage;
    }

    public String getThumbnailImage() {
        return thumbnailImage;
    }

    public void setThumbnailImage(String thumbnailImage) {
        this.thumbnailImage = thumbnailImage;
    }
}
