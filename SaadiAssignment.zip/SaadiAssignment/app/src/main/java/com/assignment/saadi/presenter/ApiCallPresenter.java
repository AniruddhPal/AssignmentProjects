package com.assignment.saadi.presenter;

import com.assignment.saadi.interfaces.ApiCallContract;
import com.assignment.saadi.model.DataModel;
import com.assignment.saadi.repository.ApiCallRepository;
import com.assignment.saadi.repository.ApiCallRepositoryCallback;

public class ApiCallPresenter implements ApiCallContract.ApiCallPresenter {

    ApiCallContract.ApiCallView apiCallView;

    public ApiCallPresenter(ApiCallContract.ApiCallView apiCallView) {
        this.apiCallView = apiCallView;
    }

    @Override
    public void hitApiCall() {
        ApiCallRepository.hitApi(new ApiCallRepositoryCallback() {
            @Override
            public void onResponseSuccess(DataModel response) {
                apiCallView.successResponse(response);
            }

            @Override
            public void onError(String failedMessage) {
                apiCallView.failResponse("Api called failed with : "+failedMessage);
            }
        });

    }
}
