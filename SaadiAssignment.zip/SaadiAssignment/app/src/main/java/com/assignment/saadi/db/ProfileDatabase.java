package com.assignment.saadi.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.assignment.saadi.model.RowDataItem;
import com.assignment.saadi.utils.Helper;

import java.util.ArrayList;

public class ProfileDatabase extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "SaadiProfile.db";

    public ProfileDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    public static final String TABLE_NAME = "ProfileInterested";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "fullName";
    public static final String COLUMN_AGE = "age";
    public static final String COLUMN_STATE = "state";
    public static final String COLUMN_CITY = "city";
    public static final String COLUMN_COUNTRY = "country";
    public static final String COLUMN_STATUS = "status";

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    "_id" + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_ID + " TEXT," +
                    COLUMN_NAME + " TEXT," +
                    COLUMN_AGE + "  NUMERIC," +
                    COLUMN_STATE + " TEXT," +
                    COLUMN_CITY + " TEXT," +
                    COLUMN_COUNTRY + " TEXT," +
                    COLUMN_STATUS + " TEXT)";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + TABLE_NAME;

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL(SQL_DELETE_ENTRIES);
        onCreate(sqLiteDatabase);
    }


    public void insertDateintoDB(RowDataItem value, String name, String status) {
        SQLiteDatabase sqld = getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(COLUMN_ID, value.getLoginObject().getUsername());
        cv.put(COLUMN_NAME, name);
        cv.put(COLUMN_AGE, value.getDobObject().getAge());
        cv.put(COLUMN_STATE, value.getLocationObject().getState());
        cv.put(COLUMN_CITY, value.getLocationObject().getCity());
        cv.put(COLUMN_COUNTRY, value.getLocationObject().getCountry());
        cv.put(COLUMN_STATUS, status);

        long rowInserted = sqld.insert(TABLE_NAME, "", cv);
        sqld.close();//This is very important to close.Never forget this.
        if (rowInserted != -1) {
            //Insert success.
            Helper.v("Saadi", "Inserted in db successfully");
        } else {
            //Inser failed.
            Helper.v("Saadi", "Insert in db failed");

        }

    }


    public ArrayList<RowDataItem> getdatafromDB() {
        ArrayList<RowDataItem> itemList = new ArrayList<>();
        SQLiteDatabase sqld = getReadableDatabase();
        Cursor cur = sqld.rawQuery("select * from " + TABLE_NAME, null);
        try {
            if (cur != null) {
                if (cur.moveToFirst()) {
                    do {
                        RowDataItem item = new RowDataItem();
                        item.getNameObject().setFirstName(cur.getString(1));
                        item.getDobObject().setAge(cur.getInt(2));
                        item.getLocationObject().setState(cur.getString(3));
                        item.getLocationObject().setCity(cur.getString(4));
                        item.getLocationObject().setCountry(cur.getString(5));
                        item.setStatus(cur.getString(6));
                        itemList.add(item);
                    } while (cur.moveToNext());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return itemList;
    }


    public void updateDateintoDB(RowDataItem value, String name, String status) {
        SQLiteDatabase sqld = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_ID, value.getLoginObject().getUsername());
        cv.put(COLUMN_NAME, name);
        cv.put(COLUMN_AGE, value.getDobObject().getAge());
        cv.put(COLUMN_STATE, value.getLocationObject().getState());
        cv.put(COLUMN_CITY, value.getLocationObject().getCity());
        cv.put(COLUMN_COUNTRY, value.getLocationObject().getCountry());
        cv.put(COLUMN_STATUS, status);

        int rowInserted = sqld.update(TABLE_NAME, cv, "id = ?", new String[]{value.getLoginObject().getUsername()});
        sqld.close();//This is very important to close.Never forget this.
        if (rowInserted != -1) {
            //Insert success.
            Helper.v("Saadi", "Updated in db successfully");
        } else {
            //Inser failed.
            Helper.v("Saadi", "Updated in db failed");

        }
    }

}
