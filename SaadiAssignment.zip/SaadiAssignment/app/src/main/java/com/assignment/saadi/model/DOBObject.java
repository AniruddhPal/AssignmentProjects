package com.assignment.saadi.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class DOBObject implements Serializable {
    @SerializedName("age")
    private Integer age;

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }
}
