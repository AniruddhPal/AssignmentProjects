package com.assignment.saadi.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class LoginObject implements Serializable {
    @SerializedName("username")
    private String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
