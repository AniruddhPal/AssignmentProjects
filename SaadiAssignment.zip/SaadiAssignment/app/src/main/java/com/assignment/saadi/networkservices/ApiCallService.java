package com.assignment.saadi.networkservices;
import com.assignment.saadi.model.DataModel;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.http.GET;
public interface ApiCallService {
    @GET("api/?results=10")
    Call<DataModel> initCall();
}
