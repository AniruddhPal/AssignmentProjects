package com.assignment.saadi.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.assignment.saadi.R;
import com.assignment.saadi.db.ProfileDatabase;
import com.assignment.saadi.interfaces.GenericClickHandler;
import com.assignment.saadi.model.RowDataItem;
import com.assignment.saadi.utils.Helper;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ApiCallAdapter extends RecyclerView.Adapter<ApiCallAdapter.MyViewHolder> {

    private ArrayList<RowDataItem> itemsList;
    private Context mContext;
    ProfileDatabase db;
//    GenericClickHandler gch;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        LinearLayout llMainLayout, llDecline, llAccept;
        TextView txtName, txtState, txtCountry, txtDeclineLabel, txtAcceptLabel;
        ImageView imageView;

        public MyViewHolder(View view) {
            super(view);
            llMainLayout = (LinearLayout) view.findViewById(R.id.ll_main_layout);
            llDecline = (LinearLayout) view.findViewById(R.id.ll_decline);
            llAccept = (LinearLayout) view.findViewById(R.id.ll_accept);
            txtName = (TextView) view.findViewById(R.id.txt_name);
            txtState = (TextView) view.findViewById(R.id.txt_age_state);
            txtCountry = (TextView) view.findViewById(R.id.txt_country_degree);
            imageView = (ImageView) view.findViewById(R.id.iv_profile_image);
            txtAcceptLabel = (TextView) view.findViewById(R.id.txt_label_accept);
            txtDeclineLabel = (TextView) view.findViewById(R.id.txt_label_decline);
        }
    }

    public ApiCallAdapter(Context mContext, ArrayList<RowDataItem> Items) {
        this.mContext = mContext;
        this.itemsList = Items;
//        this.gch = gch;
        this.db = new ProfileDatabase(mContext);
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, final int position) {

        myViewHolder.txtName.setText(Helper.validateString(itemsList.get(position).getNameObject().getFirstName()) +
                " " + initialsOfName(Helper.validateString(itemsList.get(position).getNameObject().getLastName())));

        myViewHolder.txtState.setText(String.valueOf(itemsList.get(position).getDobObject().getAge()) +
                ", " + Helper.validateString(itemsList.get(position).getLocationObject().getState()));

        myViewHolder.txtCountry.setText(Helper.validateString(itemsList.get(position).getLocationObject().getCity())
                + ", " + Helper.validateString(itemsList.get(position).getLocationObject().getCountry()));


        Picasso.get()
                .load(itemsList.get(position).getProfilePicture().getLargeImage())
                .placeholder(R.drawable.ic_baseline_perm_identity_24)
                .into(myViewHolder.imageView);

        db.insertDateintoDB(itemsList.get(position), myViewHolder.txtName.getText().toString().trim(), "11");


        myViewHolder.llAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                gch.itemClicked(itemsList.get(position), 1);
                myViewHolder.txtAcceptLabel.setText("Member accepted");
                myViewHolder.llDecline.setEnabled(false);
                itemsList.get(position).setStatus("1");
                notifyDataSetChanged();
                db.updateDateintoDB(itemsList.get(position), myViewHolder.txtName.getText().toString().trim(), "1");
            }
        });

        myViewHolder.llDecline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                gch.itemClicked(itemsList.get(position), 2);
                myViewHolder.txtDeclineLabel.setText("Member declined");
                myViewHolder.llAccept.setEnabled(false);
                itemsList.get(position).setStatus("0");
                notifyDataSetChanged();
                db.updateDateintoDB(itemsList.get(position), myViewHolder.txtName.getText().toString().trim(), "0");

            }
        });

        if (Helper.validateString(itemsList.get(position).getStatus()).equalsIgnoreCase("0")) {
            myViewHolder.txtDeclineLabel.setText("Member declined");
        } else if (Helper.validateString(itemsList.get(position).getStatus()).equalsIgnoreCase("1")) {
            myViewHolder.txtAcceptLabel.setText("Member accepted");
        } else if (Helper.validateString(itemsList.get(position).getStatus()).equalsIgnoreCase("11")) {
            myViewHolder.txtDeclineLabel.setText("Decline");
            myViewHolder.txtAcceptLabel.setText("Accept");
        }

    }


    @Override
    public int getItemCount() {
        return itemsList.size();
    }


    private String initialsOfName(String fullName) {
        String result = "";
        try {
            String[] strArray = fullName.split(" ");
            StringBuilder builder = new StringBuilder();
            if (strArray.length > 0) {
                builder.append(strArray[0], 0, 1);
            }
            result = builder.toString().trim();


        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}