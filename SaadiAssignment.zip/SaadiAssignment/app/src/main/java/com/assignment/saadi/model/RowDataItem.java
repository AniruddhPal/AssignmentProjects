package com.assignment.saadi.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
public class RowDataItem implements Serializable {
    @SerializedName("gender")
    String gender;

    @SerializedName("name")
    NameObject nameObject;

    @SerializedName("location")
    LocationObject locationObject;

    @SerializedName("dob")
    DOBObject dobObject;

    @SerializedName("picture")
    ProfilePicture profilePicture;

    @SerializedName("login")
    LoginObject loginObject;


    private String status = "11";

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LoginObject getLoginObject() {
        return loginObject;
    }

    public void setLoginObject(LoginObject loginObject) {
        this.loginObject = loginObject;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public NameObject getNameObject() {
        return nameObject;
    }

    public void setNameObject(NameObject nameObject) {
        this.nameObject = nameObject;
    }

    public LocationObject getLocationObject() {
        return locationObject;
    }

    public void setLocationObject(LocationObject locationObject) {
        this.locationObject = locationObject;
    }

    public DOBObject getDobObject() {
        return dobObject;
    }

    public void setDobObject(DOBObject dobObject) {
        this.dobObject = dobObject;
    }

    public ProfilePicture getProfilePicture() {
        return profilePicture;
    }

    public void setProfilePicture(ProfilePicture profilePicture) {
        this.profilePicture = profilePicture;
    }
}
