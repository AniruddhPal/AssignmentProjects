package com.assignment.saadi.interfaces;

public interface GenericClickHandler {
    public void itemClicked(Object obj, int type);
}
